#!/usr/bin/env python3
"""
Test script to verify the evaluation scoring system works correctly
and returns different scores for different answer qualities.
"""

import requests
import json
import time

BASE_URL = "http://localhost:8001/api"

def test_evaluation_scores():
    """Test that different answers get different evaluation scores"""
    
    print("=" * 60)
    print("TESTING EVALUATION SCORE SYSTEM")
    print("=" * 60)
    
    # Register a test user
    print("\n1. Creating test user...")
    register_data = {
        "email": f"test_{int(time.time())}@example.com",
        "password": "test123",
        "name": "Test User"
    }
    
    response = requests.post(f"{BASE_URL}/auth/register", json=register_data)
    if response.status_code != 200:
        print(f"❌ Registration failed: {response.text}")
        return
    
    token = response.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("✅ User registered successfully")
    
    # Start interview
    print("\n2. Starting interview...")
    interview_data = {
        "settings": {
            "competencies": ["Teamwork", "Leadership"],
            "num_questions": 2,
            "difficulty": "medium"
        }
    }
    
    response = requests.post(f"{BASE_URL}/interviews/start", json=interview_data, headers=headers)
    if response.status_code != 200:
        print(f"❌ Interview start failed: {response.text}")
        return
    
    interview_id = response.json()["interview_id"]
    print(f"✅ Interview started (ID: {interview_id})")
    
    # Test Answer 1: Poor quality (vague, no STAR)
    print("\n3. Testing POOR QUALITY answer...")
    poor_answer = "I worked on a project with my team. We did some work and it was successful."
    
    response = requests.post(
        f"{BASE_URL}/interviews/{interview_id}/respond",
        json={"answer_text": poor_answer},
        headers=headers
    )
    
    if response.status_code != 200:
        print(f"❌ Answer submission failed: {response.text}")
        return
    
    eval1 = response.json()["evaluation"]
    score1 = eval1["scores"]["total"]
    print(f"   Answer: '{poor_answer[:60]}...'")
    print(f"   Scores: S={eval1['scores']['situation']} T={eval1['scores']['task']} A={eval1['scores']['action']} R={eval1['scores']['result']}")
    print(f"   📊 Total Score: {score1}/20")
    
    # Test Answer 2: Good quality (clear STAR)
    print("\n4. Testing GOOD QUALITY answer...")
    good_answer = """When I was leading a cross-functional team of 8 developers (Situation), 
    we faced a critical deadline for a product launch that was at risk due to technical debt (Task). 
    I personally organized daily standups, created a priority matrix, delegated tasks based on expertise, 
    and implemented a code review process to maintain quality while speeding up delivery (Action). 
    As a result, we delivered the product 3 days early with 99.5% uptime in the first month, 
    and received positive feedback from 95% of beta users (Result)."""
    
    response = requests.post(
        f"{BASE_URL}/interviews/{interview_id}/respond",
        json={"answer_text": good_answer},
        headers=headers
    )
    
    if response.status_code != 200:
        print(f"❌ Answer submission failed: {response.text}")
        return
    
    eval2 = response.json()["evaluation"]
    score2 = eval2["scores"]["total"]
    print(f"   Answer: '{good_answer[:60]}...'")
    print(f"   Scores: S={eval2['scores']['situation']} T={eval2['scores']['task']} A={eval2['scores']['action']} R={eval2['scores']['result']}")
    print(f"   📊 Total Score: {score2}/20")
    
    # Verify scores are different
    print("\n" + "=" * 60)
    print("RESULTS:")
    print("=" * 60)
    print(f"Poor Answer Score:  {score1}/20")
    print(f"Good Answer Score:  {score2}/20")
    print(f"Score Difference:   {abs(score2 - score1)} points")
    
    if score1 == score2 == 12:
        print("\n❌ FAILED: Both answers got the same default score (12/20)")
        print("   This indicates the evaluation system is still falling back to defaults.")
    elif score1 == score2:
        print(f"\n⚠️  WARNING: Both answers got the same score ({score1}/20)")
        print("   Scores should be different for different quality answers.")
    elif score2 > score1:
        print("\n✅ SUCCESS: Evaluation system is working correctly!")
        print("   Good answer scored higher than poor answer as expected.")
    else:
        print("\n⚠️  UNEXPECTED: Poor answer scored higher than good answer")
        print("   This may indicate issues with the evaluation criteria.")
    
    # Get summary to verify past answers are stored
    print("\n5. Fetching interview summary...")
    response = requests.get(f"{BASE_URL}/interviews/{interview_id}/summary", headers=headers)
    
    if response.status_code != 200:
        print(f"❌ Summary fetch failed: {response.text}")
        return
    
    summary = response.json()
    
    print(f"✅ Summary retrieved successfully")
    print(f"\n📋 Summary includes:")
    print(f"   - Total Questions: {summary['total_questions']}")
    print(f"   - All Q&A Stored: {len(summary['all_questions_answers'])} answers")
    print(f"   - STAR Analysis: {list(summary['star_analysis'].keys())}")
    print(f"   - Personalized Advice: {len(summary['personalized_advice'])} tips")
    
    # Display STAR analysis
    if summary['star_analysis']['missing_components']:
        print(f"\n🚨 Missing Components: {', '.join(summary['star_analysis']['missing_components'])}")
    if summary['star_analysis']['weak_components']:
        print(f"⚠️  Weak Components: {', '.join(summary['star_analysis']['weak_components'])}")
    if summary['star_analysis']['strong_components']:
        print(f"✅ Strong Components: {', '.join(summary['star_analysis']['strong_components'])}")
    
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)

if __name__ == "__main__":
    try:
        test_evaluation_scores()
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
